package maxJUnitTest;

public class Maximum {
  public int findMax(int num1, int num2, int num3) {

    int max = num1;

    if (num1 > num2 && num1 > num3)
      max = num1;
    if (num2 > num1 && num2 > num3)
      max = num2;
    if (num3 > num1 && num3 > num2)
      max = num3;

    return max;
  }
}